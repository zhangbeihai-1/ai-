import ComponentView from '../../view/Component.js';
declare class TimelineView extends ComponentView {
    static type: string;
    type: string;
}
export default TimelineView;
