import GlobalModel from '../../model/Global.js';
export default function graphEdgeVisual(ecModel: GlobalModel): void;
