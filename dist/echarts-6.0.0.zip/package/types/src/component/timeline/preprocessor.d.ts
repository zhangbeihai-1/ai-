export default function timelinePreprocessor(option: any): void;
