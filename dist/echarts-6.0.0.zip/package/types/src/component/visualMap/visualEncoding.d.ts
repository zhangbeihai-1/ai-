import { StageHandler } from '../../util/types.js';
export declare const visualMapEncodingHandlers: StageHandler[];
