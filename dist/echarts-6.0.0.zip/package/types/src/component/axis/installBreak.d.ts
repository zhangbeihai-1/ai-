import type { EChartsExtensionInstallRegisters } from '../../extension.js';
export declare function installAxisBreak(registers: EChartsExtensionInstallRegisters): void;
