import PieSeriesModel from './PieSeries.js';
export default function pieLabelLayout(seriesModel: PieSeriesModel): void;
