/**
 * [CAUTION] Never export methods other than `installLegacyGridContainLabel`.
 */
export declare function installLegacyGridContainLabel(): void;
