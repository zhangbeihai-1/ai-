import { EChartsExtensionInstallRegisters } from '../../extension.js';
export declare function installLegendAction(registers: EChartsExtensionInstallRegisters): void;
