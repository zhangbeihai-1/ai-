import { EChartsExtensionInstallRegisters } from '../../extension.js';
export declare function install(registers: EChartsExtensionInstallRegisters): void;
export declare function installScatterJitter(registers: EChartsExtensionInstallRegisters): void;
