import GlobalModel from '../../model/Global.js';
export default function categoryFilter(ecModel: GlobalModel): void;
