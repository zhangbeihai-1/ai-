export declare function installAxisBreakHelper(): void;
