import { ECUnitOption } from '../../util/types.js';
export default function candlestickPreprocessor(option: ECUnitOption): void;
