import GlobalModel from '../../model/Global.js';
import ExtensionAPI from '../../core/ExtensionAPI.js';
export default function graphSimpleLayout(ecModel: GlobalModel, api: ExtensionAPI): void;
