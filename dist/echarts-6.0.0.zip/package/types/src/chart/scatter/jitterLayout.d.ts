import type GlobalModel from '../../model/Global.js';
export default function jitterLayout(ecModel: GlobalModel): void;
